﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LAB1
{
    public partial class Bai5 : Form
    {
        public Bai5()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b;
            try
            {


                a = Int32.Parse(textBox1.Text.Trim());
                b = Int32.Parse(textBox2.Text.Trim());

                if (comboBox1.Text == "Bảng cửu chương")
                {
                    int kq;
                    kq = b - a;
                    textBox3.Text = "B -A = " + kq.ToString() + Environment.NewLine;
                    for (int o = 1; o <= 10; o++)
                    {
                        textBox3.AppendText($"{o} x {kq} = {o * kq}\r\n");
                    }

                }
                else if (comboBox1.Text == "Tìm giá trị")
                {
                    int kq1 = 1;
                    long kq2 = 0;
                    int n = a - b;
                    for (int i = 1; i <= n; i++)
                    {
                        kq1 = kq1 * i;
                    }

                    for (int j = b; j > 0; j--)
                    {
                        kq2 = kq2 + (long)Math.Pow(a, j);
                    }
                    textBox3.Text = "(A-B)! = " + kq1.ToString() + Environment.NewLine + "A^1 + A^2 + A^3 + A^4 + ..... A^B = " + kq2.ToString();
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn các chức năng","Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Giá trị không hợp lệ, xin vui lòng nhập lại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Bảng cửu chương");
            comboBox1.Items.Add("Tìm giá trị");

        }
    }
}
