﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB1
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
        }

        private void Bai2_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        

        }
        private void button1_Click(object sender, EventArgs e)
        {
            int max, min;
            int num1, num2, num3;
            try
            {
                
                num1 = Int32.Parse(textBox1.Text.Trim());
                num2 = Int32.Parse(textBox2.Text.Trim());
                num3 = Int32.Parse(textBox3.Text.Trim());
                if (num1 >= num2 && num1 >= num3)
                {
                    max = num1;
                    textBox4.Text = max.ToString();
                }
                else if (num2 >= num1 && num2 >= num3)
                {
                    max = num2;
                    textBox4.Text = max.ToString();
                }
                else if (num3 >= num2 && num3 >= num1)
                {
                    max = num3;
                    textBox4.Text = max.ToString();
                }
                

                if (num1 <= num2 && num1 <= num3)
                {
                    min = num1;
                    textBox5.Text = min.ToString();
                }
                else if (num2 <= num1 && num2 <= num3)
                {
                    min = num2;
                    textBox5.Text = min.ToString();
                }
                else if (num3 <= num2 && num3 <= num1)
                {
                    min = num3;
                    textBox5.Text = min.ToString();
                }
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Giá trị không hợp lệ, xin vui lòng nhập lại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
