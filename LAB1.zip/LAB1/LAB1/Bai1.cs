﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LAB1
{
    public partial class Bai1 : Form
    {
        public Bai1()
        {
            InitializeComponent();
        }

        private void Bai1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b;
            int i = 0, j = 0, count1 = 0, count2 = 0;
            long sum = 0;
            while (i < textBox1.Text.Length)
            {
                if (textBox1.Text[i] < 48 || textBox1.Text[i] > 57)
                {
                    count1++;
                }
                i++;
            }
            while (j < textBox2.Text.Length)
            {
                if (textBox2.Text[j] < 48 || textBox2.Text[j] > 57)
                {
                    count2++;
                }
                j++;
            }
            if (count1 != 0 || count2 != 0)
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                MessageBox.Show("Vui lòng nhập số nguyên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else if (textBox1.Text == "" || textBox2.Text == "")
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                MessageBox.Show("Vui lòng nhập số nguyên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                a = Int32.Parse(textBox1.Text.Trim());
                b = Int32.Parse(textBox2.Text.Trim());
                sum = a + b;
                textBox3.Text = sum.ToString();
            }

        }
    }
}
