﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LAB1
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1;
            try
            {
                num1 = Int32.Parse(textBox1.Text.Trim());
                if (num1 == 0)
                {
                    textBox2.Text = "Không";
                }
                else if (num1 == 1)
                {
                    textBox2.Text = "Một";
                }
                else if (num1 == 2)
                {
                    textBox2.Text = "Hai";
                }
                else if (num1 == 3)
                {
                    textBox2.Text = "Ba";
                }

                else if (num1 == 4)
                {
                    textBox2.Text = "Bốn";
                }

                else if (num1 == 5)
                {
                    textBox2.Text = "Năm";
                }
                else if (num1 == 6)
                {
                    textBox2.Text = "Sáu";
                }
                else if (num1 == 7)
                {
                    textBox2.Text = "Bảy";
                }
                else if (num1 == 8)
                {
                    textBox2.Text = "Tám";
                }
                else if (num1 == 9)
                {
                    textBox2.Text = "Chín";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Giá trị không hợp lệ, xin vui lòng nhập lại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox2.Clear();
            }
        }
    }
}
