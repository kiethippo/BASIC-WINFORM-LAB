﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LAB1
{
    public partial class Bai6 : Form
    {
        public Bai6()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int day, month;
            string z = " ";
            try
            {
                day = Int32.Parse(textBox1.Text.Trim());
                month = Int32.Parse(textBox2.Text.Trim());
                if (day > 31)
                {
                    MessageBox.Show("Giá trị ngày không tồn tại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    switch (month)
                    {
                        case 1:
                            z = (day <= 19) ? "Ma Kết" : "Bảo Bình";
                            break;
                        case 2:
                            z = (day <= 18) ? "Bảo Bình" : "Song Ngư";
                            break;
                        case 4:
                            z = (day <= 19) ? "Bạch Dương" : "Kim Ngưu";
                            break;
                        case 5:
                            z = (day <= 20) ? "Kim Ngưu" : "Song Tử";
                            break;
                        case 6:
                            z = (day <= 20) ? "Song Tử" : "Cự Giải";
                            break;
                        case 7:
                            z = (day <= 22) ? "Cự Giải" : "Sư Tử";
                            break;
                        case 8:
                            z = (day <= 22) ? "Sư Tử" : "Xử Nữ";
                            break;
                        case 9:
                            z = (day <= 22) ? "Xử Nữ" : "Thiên Bình";
                            break;
                        case 10:
                            z = (day <= 22) ? "Thiên Bình" : "Bọ Cạp";
                            break;
                        case 11:
                            z = (day <= 21) ? "Bọ Cạp" : "Nhân Mã";
                            break;
                        case 12:
                            z = (day <= 21) ? "Nhân Mã" : "Ma Kết";
                            break;
                        default:
                            z = "Ngày không hợp lệ";
                            break;
                    }
                    textBox3.Text = "Cung hoàng đạo của bạn là: " + z.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Giá trị không hợp lệ, xin vui lòng nhập lại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
