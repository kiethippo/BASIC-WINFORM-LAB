﻿namespace Lab3
{
    partial class Bai4Server
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            listView1 = new ListView();
            richTextBox1 = new RichTextBox();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(574, 20);
            button1.Name = "button1";
            button1.Size = new Size(106, 104);
            button1.TabIndex = 0;
            button1.Text = "Listen";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // listView1
            // 
            listView1.Location = new Point(14, 20);
            listView1.Name = "listView1";
            listView1.Size = new Size(526, 418);
            listView1.TabIndex = 1;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.List;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(731, 20);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(387, 418);
            richTextBox1.TabIndex = 2;
            richTextBox1.Text = "";
            // 
            // button2
            // 
            button2.Enabled = false;
            button2.Location = new Point(574, 183);
            button2.Name = "button2";
            button2.Size = new Size(106, 104);
            button2.TabIndex = 3;
            button2.Text = "Xem Lịch Sử Khách Hàng";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Enabled = false;
            button3.Location = new Point(574, 334);
            button3.Name = "button3";
            button3.Size = new Size(106, 104);
            button3.TabIndex = 4;
            button3.Text = "Xuất dữ liệu phim";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Bai4Server
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1134, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(richTextBox1);
            Controls.Add(listView1);
            Controls.Add(button1);
            Name = "Bai4Server";
            Text = "Bai4Server";
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private ListView listView1;
        private RichTextBox richTextBox1;
        private Button button2;
        private Button button3;
    }
}