﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Bai4 : Form
    {
        public Bai4()
        {
            InitializeComponent();
        }

        private void isServerAlive(Thread ServerThrd)
        {
            while (true)
            {
                if (ServerThrd.IsAlive)
                {
                    button1.Enabled = false;
                }
                else
                {
                    button1.Enabled = true;
                    break;
                }
            }
        }
        private void ServerThread()
        {
            Bai4Server ChatServer = new Bai4Server();
            ChatServer.ShowDialog();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            Thread ServerThrd = new Thread(ServerThread);
            ServerThrd.Start();
            Thread isServerAliv = new Thread(() => isServerAlive(ServerThrd));
            isServerAliv.Start();
        }
        private void ClientThread()
        {
            Bai4Client ChatClient = new Bai4Client();
            ChatClient.ShowDialog();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Thread ClientThrd = new Thread(ClientThread);
            ClientThrd.Start();
        }
    }
}
