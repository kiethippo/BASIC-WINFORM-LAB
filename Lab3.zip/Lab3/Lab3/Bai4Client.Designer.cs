﻿using static System.Net.Mime.MediaTypeNames;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Lab3
{
    partial class Bai4Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox1 = new ComboBox();
            label1 = new Label();
            button1 = new Button();
            A_1 = new CheckBox();
            A_2 = new CheckBox();
            B_1 = new CheckBox();
            A_3 = new CheckBox();
            C_1 = new CheckBox();
            B_2 = new CheckBox();
            A_4 = new CheckBox();
            C_2 = new CheckBox();
            B_3 = new CheckBox();
            A_5 = new CheckBox();
            C_3 = new CheckBox();
            B_4 = new CheckBox();
            B_5 = new CheckBox();
            C_4 = new CheckBox();
            C_5 = new CheckBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            groupBox1 = new GroupBox();
            comboBox2 = new ComboBox();
            button2 = new Button();
            textBox1 = new TextBox();
            label5 = new Label();
            button3 = new Button();
            button4 = new Button();
            richTextBox1 = new RichTextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // comboBox1
            // 
            comboBox1.Enabled = false;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(118, 87);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(167, 28);
            comboBox1.TabIndex = 0;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Enabled = false;
            label1.Location = new Point(19, 87);
            label1.Name = "label1";
            label1.Size = new Size(81, 20);
            label1.TabIndex = 1;
            label1.Text = "Chọn phim";
            // 
            // button1
            // 
            button1.Enabled = false;
            button1.Location = new Point(132, 386);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(126, 31);
            button1.TabIndex = 3;
            button1.Text = "Đặt vé";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // A_1
            // 
            A_1.CheckAlign = ContentAlignment.MiddleCenter;
            A_1.Location = new Point(139, 71);
            A_1.Margin = new Padding(3, 4, 3, 4);
            A_1.Name = "A_1";
            A_1.Size = new Size(21, 24);
            A_1.TabIndex = 0;
            A_1.Text = "1";
            A_1.UseVisualStyleBackColor = true;
            // 
            // A_2
            // 
            A_2.CheckAlign = ContentAlignment.MiddleCenter;
            A_2.Location = new Point(166, 71);
            A_2.Margin = new Padding(3, 4, 3, 4);
            A_2.Name = "A_2";
            A_2.Size = new Size(21, 24);
            A_2.TabIndex = 0;
            A_2.Text = "2";
            A_2.UseVisualStyleBackColor = true;
            // 
            // B_1
            // 
            B_1.CheckAlign = ContentAlignment.MiddleCenter;
            B_1.Location = new Point(139, 104);
            B_1.Margin = new Padding(3, 4, 3, 4);
            B_1.Name = "B_1";
            B_1.Size = new Size(21, 24);
            B_1.TabIndex = 0;
            B_1.Text = "1";
            B_1.UseVisualStyleBackColor = true;
            // 
            // A_3
            // 
            A_3.CheckAlign = ContentAlignment.MiddleCenter;
            A_3.Location = new Point(192, 71);
            A_3.Margin = new Padding(3, 4, 3, 4);
            A_3.Name = "A_3";
            A_3.Size = new Size(21, 24);
            A_3.TabIndex = 0;
            A_3.Text = "3";
            A_3.UseVisualStyleBackColor = true;
            // 
            // C_1
            // 
            C_1.CheckAlign = ContentAlignment.MiddleCenter;
            C_1.Location = new Point(139, 138);
            C_1.Margin = new Padding(3, 4, 3, 4);
            C_1.Name = "C_1";
            C_1.Size = new Size(21, 24);
            C_1.TabIndex = 0;
            C_1.Text = "1";
            C_1.UseVisualStyleBackColor = true;
            // 
            // B_2
            // 
            B_2.CheckAlign = ContentAlignment.MiddleCenter;
            B_2.Location = new Point(166, 104);
            B_2.Margin = new Padding(3, 4, 3, 4);
            B_2.Name = "B_2";
            B_2.Size = new Size(21, 24);
            B_2.TabIndex = 0;
            B_2.Text = "2";
            B_2.UseVisualStyleBackColor = true;
            // 
            // A_4
            // 
            A_4.CheckAlign = ContentAlignment.MiddleCenter;
            A_4.Location = new Point(218, 71);
            A_4.Margin = new Padding(3, 4, 3, 4);
            A_4.Name = "A_4";
            A_4.Size = new Size(21, 24);
            A_4.TabIndex = 0;
            A_4.Text = "4";
            A_4.UseVisualStyleBackColor = true;
            // 
            // C_2
            // 
            C_2.CheckAlign = ContentAlignment.MiddleCenter;
            C_2.Location = new Point(166, 138);
            C_2.Margin = new Padding(3, 4, 3, 4);
            C_2.Name = "C_2";
            C_2.Size = new Size(21, 24);
            C_2.TabIndex = 0;
            C_2.Text = "2";
            C_2.UseVisualStyleBackColor = true;
            // 
            // B_3
            // 
            B_3.CheckAlign = ContentAlignment.MiddleCenter;
            B_3.Location = new Point(192, 104);
            B_3.Margin = new Padding(3, 4, 3, 4);
            B_3.Name = "B_3";
            B_3.Size = new Size(21, 24);
            B_3.TabIndex = 0;
            B_3.Text = "3";
            B_3.UseVisualStyleBackColor = true;
            // 
            // A_5
            // 
            A_5.CheckAlign = ContentAlignment.MiddleCenter;
            A_5.Location = new Point(245, 71);
            A_5.Margin = new Padding(3, 4, 3, 4);
            A_5.Name = "A_5";
            A_5.Size = new Size(21, 24);
            A_5.TabIndex = 0;
            A_5.Text = "5";
            A_5.UseVisualStyleBackColor = true;
            // 
            // C_3
            // 
            C_3.CheckAlign = ContentAlignment.MiddleCenter;
            C_3.Location = new Point(192, 138);
            C_3.Margin = new Padding(3, 4, 3, 4);
            C_3.Name = "C_3";
            C_3.Size = new Size(21, 24);
            C_3.TabIndex = 0;
            C_3.Text = "3";
            C_3.UseVisualStyleBackColor = true;
            // 
            // B_4
            // 
            B_4.CheckAlign = ContentAlignment.MiddleCenter;
            B_4.Location = new Point(218, 104);
            B_4.Margin = new Padding(3, 4, 3, 4);
            B_4.Name = "B_4";
            B_4.Size = new Size(21, 24);
            B_4.TabIndex = 0;
            B_4.Text = "4";
            B_4.UseVisualStyleBackColor = true;
            // 
            // B_5
            // 
            B_5.CheckAlign = ContentAlignment.MiddleCenter;
            B_5.Location = new Point(245, 104);
            B_5.Margin = new Padding(3, 4, 3, 4);
            B_5.Name = "B_5";
            B_5.Size = new Size(21, 24);
            B_5.TabIndex = 0;
            B_5.Text = "5";
            B_5.UseVisualStyleBackColor = true;
            // 
            // C_4
            // 
            C_4.CheckAlign = ContentAlignment.MiddleCenter;
            C_4.Location = new Point(218, 138);
            C_4.Margin = new Padding(3, 4, 3, 4);
            C_4.Name = "C_4";
            C_4.Size = new Size(21, 24);
            C_4.TabIndex = 0;
            C_4.Text = "4";
            C_4.UseVisualStyleBackColor = true;
            // 
            // C_5
            // 
            C_5.CheckAlign = ContentAlignment.MiddleCenter;
            C_5.Location = new Point(245, 138);
            C_5.Margin = new Padding(3, 4, 3, 4);
            C_5.Name = "C_5";
            C_5.Size = new Size(21, 24);
            C_5.TabIndex = 0;
            C_5.Text = "5";
            C_5.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(71, 71);
            label2.Name = "label2";
            label2.Size = new Size(19, 20);
            label2.TabIndex = 1;
            label2.Text = "A";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(71, 106);
            label3.Name = "label3";
            label3.Size = new Size(18, 20);
            label3.TabIndex = 1;
            label3.Text = "B";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(71, 139);
            label4.Name = "label4";
            label4.Size = new Size(18, 20);
            label4.TabIndex = 1;
            label4.Text = "C";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(C_5);
            groupBox1.Controls.Add(C_4);
            groupBox1.Controls.Add(B_5);
            groupBox1.Controls.Add(B_4);
            groupBox1.Controls.Add(C_3);
            groupBox1.Controls.Add(A_5);
            groupBox1.Controls.Add(B_3);
            groupBox1.Controls.Add(C_2);
            groupBox1.Controls.Add(A_4);
            groupBox1.Controls.Add(B_2);
            groupBox1.Controls.Add(C_1);
            groupBox1.Controls.Add(A_3);
            groupBox1.Controls.Add(B_1);
            groupBox1.Controls.Add(A_2);
            groupBox1.Controls.Add(A_1);
            groupBox1.Enabled = false;
            groupBox1.Location = new Point(19, 123);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(379, 240);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Chọn ghế";
            // 
            // comboBox2
            // 
            comboBox2.Enabled = false;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(291, 87);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(107, 28);
            comboBox2.TabIndex = 4;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // button2
            // 
            button2.Location = new Point(19, 386);
            button2.Name = "button2";
            button2.Size = new Size(107, 30);
            button2.TabIndex = 5;
            button2.Text = "Kết nối";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox1
            // 
            textBox1.Enabled = false;
            textBox1.Location = new Point(20, 32);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(186, 27);
            textBox1.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(19, 9);
            label5.Name = "label5";
            label5.Size = new Size(116, 20);
            label5.TabIndex = 7;
            label5.Text = "Nhập Họ Và Tên";
            // 
            // button3
            // 
            button3.Enabled = false;
            button3.Location = new Point(264, 385);
            button3.Name = "button3";
            button3.Size = new Size(134, 32);
            button3.TabIndex = 8;
            button3.Text = "Save file";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Enabled = false;
            button4.Location = new Point(424, 12);
            button4.Name = "button4";
            button4.Size = new Size(226, 47);
            button4.TabIndex = 9;
            button4.Text = "Xem Lịch Sử Khách Hàng";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(424, 69);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.ReadOnly = true;
            richTextBox1.Size = new Size(579, 345);
            richTextBox1.TabIndex = 10;
            richTextBox1.Text = "";
            // 
            // Bai4Client
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1020, 430);
            Controls.Add(richTextBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label5);
            Controls.Add(textBox1);
            Controls.Add(button2);
            Controls.Add(comboBox2);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Bai4Client";
            Text = "Bai5";
            Activated += comboBox2_SelectedIndexChanged;
            FormClosing += Bai4Client_FormClosing;
            Load += Bai4Client_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox1;
        private Label label1;
        private Button button1;
        private CheckBox A_1;
        private CheckBox A_2;
        private CheckBox B_1;
        private CheckBox A_3;
        private CheckBox C_1;
        private CheckBox B_2;
        private CheckBox A_4;
        private CheckBox C_2;
        private CheckBox B_3;
        private CheckBox A_5;
        private CheckBox C_3;
        private CheckBox B_4;
        private CheckBox B_5;
        private CheckBox C_4;
        private CheckBox C_5;
        private Label label2;
        private Label label3;
        private Label label4;
        private GroupBox groupBox1;
        private ComboBox comboBox2;
        private Button button2;
        private TextBox textBox1;
        private Label label5;
        private Button button3;
        private Button button4;
        private RichTextBox richTextBox1;
    }
}