﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Newtonsoft.Json;

namespace Lab3
{
    public partial class Bai4Client : Form
    {
        class Phim
        {
            public string TenPhim { get; set; }
            public int GiaVeChuan { get; set; }
            public int[] PhongChieu { get; set; }
        }
        class LichSuKhachhang
        {
            public string Hoten { get; set; }
            public string Vedachon { get; set; }
            public string TenPhim { get; set; }
            public int PhongChieu { get; set; }
            public int Sotiencantra { get; set; }
        }

        class PhimOut
        {
            public string TenPhim { get; set; }
            public int GiaVeChuan { get; set; }
            public int[] PhongChieu { get; set; }
            public int DoanhThu { get; set; }
            public int SoLuongVe { get; set; }
            public int SoLuongVeBanRa { get; set; }
            public int SoLuongVeConTon { get; set; }
            public int XepHangDoanhThu { get; set; }
        }
        static void BubbleSort(int[] arr)
        {
            int n = arr.Length;
            bool swapped;
            do
            {
                swapped = false;
                for (int i = 0; i < n - 1; i++)
                {
                    if (arr[i] < arr[i + 1]) // Đổi dấu so sánh từ > sang <
                    {
                        // Hoán đổi giá trị của arr[i] và arr[i+1]
                        int temp = arr[i];
                        arr[i] = arr[i + 1];
                        arr[i + 1] = temp;
                        swapped = true;
                    }
                }
                n--; // Giảm số lần lặp để loại bỏ phần tử đã sắp xếp
            } while (swapped);
        }
        List<LichSuKhachhang> lichSuKhachhangs = new List<LichSuKhachhang>();
        List<Phim>? phims = new List<Phim>();
        List<PhimOut> phimOuts = new List<PhimOut>();
        int[] phim1p1 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim1p2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim1p3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim2p2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim2p3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim3p1 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim4p3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int Doanhthuphim1 = 0;
        int Doanhthuphim2 = 0;
        int Doanhthuphim3 = 0;
        int Doanhthuphim4 = 0;
        int VePhim1 = 45;
        int VePhim2 = 30;
        int VePhim3 = 15;
        int VePhim4 = 15;
        private TcpClient tcpClient;
        private NetworkStream ns;
        private IPEndPoint ipEndPoint;
        private Thread UpdateUI;
        public Bai4Client()
        {
            InitializeComponent();
        }
        private void UpdateUIThread(string text)
        {
            //listLog.Items.Add(new ListViewItem(text));
        }
        private void SendData(string msg)
        {
            //3 Tạo luồng để đọc và ghi dữ liệu dựa trên NetworkStream
            ns = tcpClient.GetStream();
            Byte[] data = System.Text.Encoding.UTF8.GetBytes(msg);
            ns.Write(data, 0, data.Length);
        }
        private void ReceiveFromSever()
        {
            //thiet lap ket noi de nhan du lieu tu server
            try
            {
                byte[] recv = new byte[999999];
                while (true)
                {
                    string text = "";
                    int bytesReceived = tcpClient.Client.Receive(recv);
                    text = Encoding.UTF8.GetString(recv, 0, bytesReceived);
                    string listViewString = text;
                    string[] nhan = text.Split('*');
                    phimOuts = JsonConvert.DeserializeObject<List<PhimOut>>(nhan[0]);
                    lichSuKhachhangs = JsonConvert.DeserializeObject<List<LichSuKhachhang>>(nhan[8]);
                    phim1p1 = nhan[1].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim1p2 = nhan[2].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim1p3 = nhan[3].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim2p2 = nhan[4].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim2p3 = nhan[5].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim3p1 = nhan[6].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim4p3 = nhan[7].Split(',').Select(n => int.Parse(n)).ToArray();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Đóng kết nối!");
                this.Close();
            }
        }
        private bool NewClient()
        {
            try
            {
                //1 Tạo đối tượng TcpClient
                tcpClient = new TcpClient();
                //2 Kết nối đến Server với 1 địa chỉ Ip và Port xác định
                ipEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080);
                tcpClient.Connect(ipEndPoint);
                ns = tcpClient.GetStream();
                Thread Receiver = new Thread(ReceiveFromSever);
                Receiver.Start();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tcpClient = null;
                ipEndPoint = null;
                this.Close();
                return false;
            }
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                int demso = 0;
                if (comboBox1.Text == "Đào, phở và piano")
                {
                    if (comboBox2.Text == "1")
                    {
                        foreach (CheckBox checkBox in list)
                        {
                            if (phim1p1[demso] == 1)
                            {
                                checkBox.Enabled = false;
                            }
                            else { checkBox.Enabled = true; checkBox.Checked = false; }
                            demso++;
                        }
                    }
                    else if (comboBox2.Text == "2")
                    {
                        foreach (CheckBox checkBox in list)
                        {
                            if (phim1p2[demso] == 1)
                            {
                                checkBox.Enabled = false;
                            }
                            else { checkBox.Enabled = true; checkBox.Checked = false; }
                            demso++;
                        }
                    }
                    else if (comboBox2.Text == "3")
                    {
                        foreach (CheckBox checkBox in list)
                        {
                            if (phim1p3[demso] == 1)
                            {
                                checkBox.Enabled = false;
                            }
                            else { checkBox.Enabled = true; checkBox.Checked = false; }
                            demso++;
                        }
                    }
                }
                else if (comboBox1.Text == "Mai")
                {
                    if (comboBox2.Text == "2")
                    {
                        foreach (CheckBox checkBox in list)
                        {
                            if (phim2p2[demso] == 1)
                            {
                                checkBox.Enabled = false;
                            }
                            else { checkBox.Enabled = true; checkBox.Checked = false; }
                            demso++;
                        }
                    }
                    else if (comboBox2.Text == "3")
                    {
                        foreach (CheckBox checkBox in list)
                        {
                            if (phim2p3[demso] == 1)
                            {
                                checkBox.Enabled = false;
                            }
                            else { checkBox.Enabled = true; checkBox.Checked = false; }
                            demso++;
                        }
                    }
                }
                else if (comboBox1.Text == "Gặp lại chị bầu")
                {
                    foreach (CheckBox checkBox in list)
                    {
                        if (phim3p1[demso] == 1)
                        {
                            checkBox.Enabled = false;
                        }
                        else { checkBox.Enabled = true; checkBox.Checked = false; }
                        demso++;
                    }
                }
                else if (comboBox1.Text == "Tarot")
                {
                    foreach (CheckBox checkBox in list)
                    {
                        if (phim4p3[demso] == 1)
                        {
                            checkBox.Enabled = false;
                        }
                        else { checkBox.Enabled = true; checkBox.Checked = false; }
                        demso++;
                    }
                }
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Phim selectedPhim = comboBox1.SelectedItem as Phim;
            comboBox2.DataSource = selectedPhim.PhongChieu;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Users\ASUS\Downloads\phim.json";
            try
            {
                FileStream fileStream = new FileStream(filePath, FileMode.Open);
                phims = System.Text.Json.JsonSerializer.Deserialize<List<Phim>>(fileStream);
                comboBox1.DataSource = phims;
                comboBox1.DisplayMember = "TenPhim";
                fileStream.Close();
                int h = 0;
                foreach (Phim phim in phims)
                {
                    PhimOut phimOut = new PhimOut
                    {
                        TenPhim = phim.TenPhim,
                        GiaVeChuan = phim.GiaVeChuan,
                        PhongChieu = phim.PhongChieu,
                        DoanhThu = 0,
                        SoLuongVe = 0,
                        SoLuongVeBanRa = 0,
                        SoLuongVeConTon = 0,
                        XepHangDoanhThu = 0
                    };
                    phimOuts.Add(phimOut);
                }
            }
            catch (Exception d)
            {
                Console.WriteLine("Error: " + d.Message);
            }
            comboBox1.Enabled = true;
            comboBox2.Enabled = true;
            button1.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            textBox1.Enabled = true;
            groupBox1.Enabled = true;
        }

        private void Bai4Client_Load(object sender, EventArgs e)
        {
            if (!NewClient()) this.Close();
        }
        private bool CloseClient()
        {
            try
            {
                if (tcpClient != null)
                {
                    byte[] data = System.Text.Encoding.UTF8.GetBytes(textBox1.Text + ": quit");
                    ns = tcpClient.GetStream();
                    ns.Write(data, 0, data.Length);
                    ns.Close();
                    tcpClient.Close();
                    return true;
                }
                return true;
            }
            catch (Exception)
            {
                this.Close();
                return true;
            }
            //5 Dùng phương thức Write để gửi dữ liệu mang dấu hiệu kết thúc cho Server
            // biết và đóng kết nối
        }
        private void Bai4Client_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!CloseClient())
            {
                e.Cancel = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Phim selectedPhim = comboBox1.SelectedItem as Phim;
            int phongdachon = int.Parse(comboBox2.Text);
            LichSuKhachhang a = new LichSuKhachhang();
            int demso = 0;
            a.TenPhim = selectedPhim.TenPhim;
            a.Hoten = textBox1.Text;
            if (selectedPhim.TenPhim == "Đào, phở và piano")
            {
                if (phongdachon == 1)
                {
                    List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                    foreach (CheckBox checkBox in list)
                    {

                        if (checkBox.Checked == true && checkBox.Enabled == true)
                        {
                            string hangGhe = checkBox.Name.Split("_")[0];
                            int soTTGhe = int.Parse(checkBox.Name.Split("_")[1]);
                            int giaVeChuan = selectedPhim.GiaVeChuan;
                            int giaVeThucTe = 0;
                            if (soTTGhe == 1 || soTTGhe == 5)
                            {
                                giaVeThucTe = giaVeChuan / 4;
                            }
                            else
                            {
                                if (hangGhe == "B")
                                {
                                    giaVeThucTe = giaVeChuan * 2;
                                }
                                else giaVeThucTe = giaVeChuan;
                            }
                            checkBox.Enabled = false;
                            Doanhthuphim1 += giaVeThucTe;
                            a.Vedachon += checkBox.Name + " ";
                            a.PhongChieu = 1;
                            a.Sotiencantra += giaVeThucTe;
                            phim1p1[demso] = 1;
                            VePhim1--;
                        }
                        demso++;
                    }
                }
                else if (phongdachon == 2)
                {
                    List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                    foreach (CheckBox checkBox in list)
                    {

                        if (checkBox.Checked == true && checkBox.Enabled == true)
                        {
                            string hangGhe = checkBox.Name.Split("_")[0];
                            int soTTGhe = int.Parse(checkBox.Name.Split("_")[1]);
                            int giaVeChuan = selectedPhim.GiaVeChuan;
                            int giaVeThucTe = 0;
                            if (soTTGhe == 1 || soTTGhe == 5)
                            {
                                giaVeThucTe = giaVeChuan / 4;
                            }
                            else
                            {
                                if (hangGhe == "B")
                                {
                                    giaVeThucTe = giaVeChuan * 2;
                                }
                                else giaVeThucTe = giaVeChuan;
                            }
                            checkBox.Enabled = false;
                            Doanhthuphim1 += giaVeThucTe;
                            a.Vedachon += checkBox.Name + " ";
                            a.PhongChieu = 2;
                            a.Sotiencantra += giaVeThucTe;
                            phim1p2[demso] = 1;
                            VePhim1--;
                        }
                        demso++;
                    }
                }
                else if (phongdachon == 3)
                {
                    List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                    foreach (CheckBox checkBox in list)
                    {

                        if (checkBox.Checked == true && checkBox.Enabled == true)
                        {
                            string hangGhe = checkBox.Name.Split("_")[0];
                            int soTTGhe = int.Parse(checkBox.Name.Split("_")[1]);
                            int giaVeChuan = selectedPhim.GiaVeChuan;
                            int giaVeThucTe = 0;
                            if (soTTGhe == 1 || soTTGhe == 5)
                            {
                                giaVeThucTe = giaVeChuan / 4;
                            }
                            else
                            {
                                if (hangGhe == "B")
                                {
                                    giaVeThucTe = giaVeChuan * 2;
                                }
                                else giaVeThucTe = giaVeChuan;
                            }
                            checkBox.Enabled = false;
                            Doanhthuphim1 += giaVeThucTe;
                            a.Vedachon += checkBox.Name + " ";
                            a.PhongChieu = 3;
                            a.Sotiencantra += giaVeThucTe;
                            phim1p3[demso] = 1;
                            VePhim1--;
                        }
                        demso++;
                    }
                }
            }
            else if (selectedPhim.TenPhim == "Mai")
            {
                if (phongdachon == 2)
                {
                    List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                    foreach (CheckBox checkBox in list)
                    {

                        if (checkBox.Checked == true && checkBox.Enabled == true)
                        {
                            string hangGhe = checkBox.Name.Split("_")[0];
                            int soTTGhe = int.Parse(checkBox.Name.Split("_")[1]);
                            int giaVeChuan = selectedPhim.GiaVeChuan;
                            int giaVeThucTe = 0;
                            if (soTTGhe == 1 || soTTGhe == 5)
                            {
                                giaVeThucTe = giaVeChuan / 4;
                            }
                            else
                            {
                                if (hangGhe == "B")
                                {
                                    giaVeThucTe = giaVeChuan * 2;
                                }
                                else giaVeThucTe = giaVeChuan;
                            }
                            checkBox.Enabled = false;
                            Doanhthuphim2 += giaVeThucTe;
                            a.Vedachon += checkBox.Name + " ";
                            a.PhongChieu = 2;
                            a.Sotiencantra += giaVeThucTe;
                            phim2p2[demso] = 1;
                            VePhim2--;
                        }
                        demso++;
                    }
                }
                else if (phongdachon == 3)
                {
                    List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                    foreach (CheckBox checkBox in list)
                    {

                        if (checkBox.Checked == true && checkBox.Enabled == true)
                        {
                            string hangGhe = checkBox.Name.Split("_")[0];
                            int soTTGhe = int.Parse(checkBox.Name.Split("_")[1]);
                            int giaVeChuan = selectedPhim.GiaVeChuan;
                            int giaVeThucTe = 0;
                            if (soTTGhe == 1 || soTTGhe == 5)
                            {
                                giaVeThucTe = giaVeChuan / 4;
                            }
                            else
                            {
                                if (hangGhe == "B")
                                {
                                    giaVeThucTe = giaVeChuan * 2;
                                }
                                else giaVeThucTe = giaVeChuan;
                            }
                            checkBox.Enabled = false;
                            Doanhthuphim2 += giaVeThucTe;
                            a.Vedachon += checkBox.Name + " ";
                            a.PhongChieu = 3;
                            a.Sotiencantra += giaVeThucTe;
                            phim2p3[demso] = 1;
                            VePhim2--;
                        }
                        demso++;
                    }
                }
            }
            else if (selectedPhim.TenPhim == "Gặp lại chị bầu")
            {
                List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                foreach (CheckBox checkBox in list)
                {

                    if (checkBox.Checked == true && checkBox.Enabled == true)
                    {
                        string hangGhe = checkBox.Name.Split("_")[0];
                        int soTTGhe = int.Parse(checkBox.Name.Split("_")[1]);
                        int giaVeChuan = selectedPhim.GiaVeChuan;
                        int giaVeThucTe = 0;
                        if (soTTGhe == 1 || soTTGhe == 5)
                        {
                            giaVeThucTe = giaVeChuan / 4;
                        }
                        else
                        {
                            if (hangGhe == "B")
                            {
                                giaVeThucTe = giaVeChuan * 2;
                            }
                            else giaVeThucTe = giaVeChuan;
                        }
                        checkBox.Enabled = false;
                        Doanhthuphim3 += giaVeThucTe;
                        a.Vedachon += checkBox.Name + " ";
                        a.PhongChieu = 1;
                        a.Sotiencantra += giaVeThucTe;
                        phim3p1[demso] = 1;
                        VePhim3--;
                    }
                    demso++;
                }
            }
            else if (selectedPhim.TenPhim == "Tarot")
            {
                List<CheckBox> list = groupBox1.Controls.OfType<CheckBox>().ToList();
                foreach (CheckBox checkBox in list)
                {

                    if (checkBox.Checked == true && checkBox.Enabled == true)
                    {
                        string hangGhe = checkBox.Name.Split("_")[0];
                        int soTTGhe = int.Parse(checkBox.Name.Split("_")[1]);
                        int giaVeChuan = selectedPhim.GiaVeChuan;
                        int giaVeThucTe = 0;
                        if (soTTGhe == 1 || soTTGhe == 5)
                        {
                            giaVeThucTe = giaVeChuan / 4;
                        }
                        else
                        {
                            if (hangGhe == "B")
                            {
                                giaVeThucTe = giaVeChuan * 2;
                            }
                            else giaVeThucTe = giaVeChuan;
                        }
                        checkBox.Enabled = false;
                        Doanhthuphim4 += giaVeThucTe;
                        a.Vedachon += checkBox.Name + " ";
                        a.PhongChieu = 3;
                        a.Sotiencantra += giaVeThucTe;
                        phim4p3[demso] = 1;
                        VePhim4--;
                    }
                    demso++;
                }
            }
            lichSuKhachhangs.Add(a);
            int h = 0;
            int[] ints = { VePhim1, VePhim2, VePhim3, VePhim4 };
            int[] Doanhthus = { Doanhthuphim1, Doanhthuphim2, Doanhthuphim3, Doanhthuphim4 };
            int[] Xeploai = { Doanhthuphim1, Doanhthuphim2, Doanhthuphim3, Doanhthuphim4 };
            BubbleSort(Xeploai);
            foreach (PhimOut phimOut in phimOuts)
            {
                phimOut.SoLuongVeBanRa = ints[h];
                phimOut.DoanhThu = Doanhthus[h];
                phimOut.SoLuongVe = 15 * phimOut.PhongChieu.Length;
                phimOut.SoLuongVeConTon = phimOut.SoLuongVe - phimOut.SoLuongVeBanRa;
                for (int i = 0; i < Doanhthus.Length; i++)
                {
                    if (Doanhthus[h] == Xeploai[i])
                    { phimOut.XepHangDoanhThu = i + 1; }
                }
                h++;
            }
            string phim = JsonConvert.SerializeObject(phimOuts);
            string guidata = phim + "*";
            string str = string.Join(",", phim1p1.Select(n => n.ToString()));
            guidata += str + "*";
            string str1 = string.Join(",", phim1p2.Select(n => n.ToString()));
            guidata += str1 + "*";
            string str2 = string.Join(",", phim1p3.Select(n => n.ToString()));
            guidata += str2 + "*";
            string str3 = string.Join(",", phim2p2.Select(n => n.ToString()));
            guidata += str3 + "*";
            string str4 = string.Join(",", phim2p3.Select(n => n.ToString()));
            guidata += str4 + "*";
            string str5 = string.Join(",", phim3p1.Select(n => n.ToString()));
            guidata += str5 + "*";
            string str6 = string.Join(",", phim4p3.Select(n => n.ToString()));
            guidata += str6 + "*";
            string lichsu = JsonConvert.SerializeObject(lichSuKhachhangs);
            guidata += lichsu;
            SendData(guidata);
            //for(int i=0; i<test.Length; i++)
            //{
            //    richTextBox1.Text += test[i]+"\r\n"+"\r\n";
            // }
        }

        private void Bai4Client_Activated(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            foreach (LichSuKhachhang lichSuKhachhang in lichSuKhachhangs)
            {
                richTextBox1.Text += "{ \r\n";
                richTextBox1.Text += "Họ và Tên : " + lichSuKhachhang.Hoten + "\r\n" + "Tên Phim : " + lichSuKhachhang.TenPhim + "\r\n"
                    + "Vé Đã Chọn : " + lichSuKhachhang.Vedachon + "\r\n" + "Phòng Chiếu : " + lichSuKhachhang.PhongChieu + "\r\n"
                    + "Số Tiền Cần Trả : " + lichSuKhachhang.Sotiencantra + "\r\n";
                richTextBox1.Text += "} \r\n" + "\r\n";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string json = JsonConvert.SerializeObject(phimOuts, Formatting.Indented);
            string duongDanTepTin = @"D:\output.json";
            File.WriteAllText(duongDanTepTin, json);
            MessageBox.Show("Tệp đã được lưu ở ổ đĩa D", "Thành Công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
