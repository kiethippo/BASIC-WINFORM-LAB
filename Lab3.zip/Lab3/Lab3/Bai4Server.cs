﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Lab3
{
    public partial class Bai4Server : Form
    {
        private int bytesReceived = 0;
        private List<Socket> ListClient;
        private Socket listenerSocket;
        private IPEndPoint ipepServer;
        public Bai4Server()
        {
            InitializeComponent();
        }
        class LichSuKhachhang
        {
            public string Hoten { get; set; }
            public string Vedachon { get; set; }
            public string TenPhim { get; set; }
            public int PhongChieu { get; set; }
            public int Sotiencantra { get; set; }
        }

        class PhimOut
        {
            public string TenPhim { get; set; }
            public int GiaVeChuan { get; set; }
            public int[] PhongChieu { get; set; }
            public int DoanhThu { get; set; }
            public int SoLuongVe { get; set; }
            public int SoLuongVeBanRa { get; set; }
            public int SoLuongVeConTon { get; set; }
            public int XepHangDoanhThu { get; set; }
        }
        List<LichSuKhachhang> lichSuKhachhangs = new List<LichSuKhachhang>();
        List<PhimOut> phimOuts = new List<PhimOut>();
        int[] phim1p1 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim1p2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim1p3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim2p2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim2p3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim3p1 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] phim4p3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        private void ListenThread()
        {
            bytesReceived = 0;
            listenerSocket = new Socket(
                 AddressFamily.InterNetwork,
                 SocketType.Stream,
                 ProtocolType.Tcp
                 );
            ipepServer = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080);
            listenerSocket.Bind(ipepServer);
            listView1.Items.Add(new ListViewItem("Listenning on: " + ipepServer.ToString()));
            listenerSocket.Listen(-1);
            AcceptClient();
        }
        private void AcceptClient()
        {
            try
            {
                ListClient = new List<Socket>();
                while (true)
                {
                    Socket clientSocket = listenerSocket.Accept();
                    ListClient.Add(clientSocket);
                    listView1.Items.Add(new ListViewItem("New Client Connected: " + clientSocket.RemoteEndPoint.ToString()));
                    Thread receiver = new Thread(() => ReceiveDataThread(clientSocket));
                    receiver.Start();
                }
            }
            catch (Exception)
            {
                CloseMe();
            }
        }

        private void ReceiveDataThread(Socket clientSocket)
        {
            try
            {
                while (true && clientSocket.Connected && listenerSocket.LocalEndPoint != null)
                {
                    string msg = "";
                    byte[] recv = new byte[9999999];
                    bytesReceived = clientSocket.Receive(recv);
                    msg = Encoding.UTF8.GetString(recv, 0, bytesReceived);
                    string listViewString = msg;
                    string[] nhan = msg.Split('*');
                    phimOuts = JsonConvert.DeserializeObject<List<PhimOut>>(nhan[0]);
                    LichSuKhachhang lichSu = new LichSuKhachhang();
                    lichSuKhachhangs = JsonConvert.DeserializeObject<List<LichSuKhachhang>>(nhan[8]);
                    phim1p1 = nhan[1].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim1p2 = nhan[2].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim1p3 = nhan[3].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim2p2 = nhan[4].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim2p3 = nhan[5].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim3p1 = nhan[6].Split(',').Select(n => int.Parse(n)).ToArray();
                    phim4p3 = nhan[7].Split(',').Select(n => int.Parse(n)).ToArray();
                    listView1.Items.Add(clientSocket.RemoteEndPoint.ToString() + ": đã đặt vé");
                    broadcast(msg);
                    if (msg.Contains("quit"))
                    {
                        CloseClientConnection(clientSocket);
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Đóng kết nối!");
                this.Close();
            }
        }

        private void CloseClientConnection(Socket clientSocket)
        {
            clientSocket.Close();
            foreach (var item in ListClient.ToArray())
            {
                if (item == clientSocket)
                {
                    ListClient.RemoveAt(ListClient.IndexOf(item));
                }
            }
        }

        private void SendData(string msg, Socket client)
        {
            Byte[] data = System.Text.Encoding.UTF8.GetBytes(msg);
            client.Send(data);
        }

        private void broadcast(string msg)
        {
            foreach (var item in ListClient)
            {
                SendData(msg, item);
            }
        }

        private void CloseMe()
        {
            byte[] recv = new byte[9999999];
            StopListening();

            foreach (var item in ListClient.ToArray())
            {
                CloseClientConnection(item);
            }

            ListClient.Clear();

            recv = null;
            bytesReceived = 0;
            ipepServer = null;
        }

        private void StopListening()
        {
            if (listenerSocket != null)
            {
                broadcast("server quit");

                if (listView1.SelectedItems.Count == 0 && listView1.Items.Count != 0)
                {
                    listView1.Items.Clear();
                }

                listenerSocket.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            Thread StartListenThread = new Thread(ListenThread);
            if (!StartListenThread.IsAlive)
            {
                StartListenThread.Start();
            }
            button2.Enabled = true;
            button3.Enabled = true;
            button1.Text = "Listenning...";
            if (listView1.Items.Count != 0)
            {
                listView1.Items.Clear();
                listView1.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            foreach (LichSuKhachhang lichSuKhachhang in lichSuKhachhangs)
            {
                richTextBox1.Text += "{ \r\n";
                richTextBox1.Text += "Họ và Tên : " + lichSuKhachhang.Hoten + "\r\n" + "Tên Phim : " + lichSuKhachhang.TenPhim + "\r\n"
                    + "Vé Đã Chọn : " + lichSuKhachhang.Vedachon + "\r\n" + "Phòng Chiếu : " + lichSuKhachhang.PhongChieu + "\r\n"
                    + "Số Tiền Cần Trả : " + lichSuKhachhang.Sotiencantra + "\r\n";
                richTextBox1.Text += "} \r\n" + "\r\n";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string json = JsonConvert.SerializeObject(phimOuts, Formatting.Indented);
            string duongDanTepTin = @"D:\output.json";
            File.WriteAllText(duongDanTepTin, json);
            MessageBox.Show("Tệp đã được lưu ở ổ đĩa D", "Thành Công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
