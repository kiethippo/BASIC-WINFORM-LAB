﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LAB2
{
    public partial class Bai4 : Form
    {
        private string[] dulieusinhvien;
        private int chiso = 0;
        private int sotrang;
        private int tranght = 1; //trang hiện đang ở
        public Bai4()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (chiso < dulieusinhvien.Length - 1)
            {
                chiso++;
                DisplayStudenInfo(chiso);
            }
            else
            {
                MessageBox.Show("bạn đang ở cuối danh sách");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (chiso > 0)
            {
                chiso--;
                DisplayStudenInfo(chiso);
                CapNhatTrang();


            }
            else
            {
                MessageBox.Show("bạn đang ở cuối danh sách");
            }
        }
        private void CapNhatTrang()
        {
            tranght = chiso + 1;
            label15.Text = $"{tranght}";
        }
        private void DisplayStudenInfo(int index)
        {
            if (index >= 0 && index < dulieusinhvien.Length)
            {
                string[] studentInfo = dulieusinhvien[index].Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);

                // Hiển thị thông tin sinh viên lên các TextBox
                textBox8.Text = studentInfo[0].Trim();
                textBox10.Text = studentInfo[1].Trim();
                textBox12.Text = studentInfo[2].Trim();
                textBox14.Text = studentInfo[3].Trim();
                textBox9.Text = studentInfo[4].Trim();
                textBox11.Text = studentInfo[5].Trim();

                // Tính điểm trung bình
                float diem1, diem2, diem3;
                if (float.TryParse(textBox14.Text, out diem1) &&
                    float.TryParse(textBox9.Text, out diem2) &&
                    float.TryParse(textBox11.Text, out diem3))
                {
                    float diemTrungBinh = (diem1 + diem2 + diem3) / 3;
                    textBox13.Text = diemTrungBinh.ToString();
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {


            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);

            try
            {
                //richTextBox1.Clear();
                //string noidung = richTextBox1.Text;
                using (StreamReader sr = new StreamReader(fs))
                {
                    string noidung = sr.ReadToEnd();
                    richTextBox1.Text = noidung;
                }

                MessageBox.Show("nội dung được nhập thành công");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi đọc ", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }





        }

        private void Bai4_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string content = richTextBox1.Text;
                string[] students = content.Split(new string[] { "\r\n\r\n", "\n\n", "\r\r" }, StringSplitOptions.RemoveEmptyEntries);
                
                dulieusinhvien = students;

                
                chiso = dulieusinhvien.Length;

              
                DisplayStudenInfo(chiso);

              
                CapNhatTrang();

                MessageBox.Show("Đã đọc thông tin từ tập tin input.txt thành công.");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi đọc ", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text.Length != 8 ||
                textBox3.Text.Length != 10 || !textBox3.Text.StartsWith("0") ||
                textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đủ thông tin và đúng định dạng.");
                return;
            }
            float diem1, diem2, diem3;
            if (!float.TryParse(textBox4.Text, out diem1) || diem1 < 0 || diem1 > 10 ||
                !float.TryParse(textBox5.Text, out diem2) || diem2 < 0 || diem2 > 10 ||
                !float.TryParse(textBox6.Text, out diem3) || diem3 < 0 || diem3 > 10)
            {
                MessageBox.Show("Điểm môn học phải nằm trong khoảng từ 0 đến 10.");
                return;
            }
            richTextBox1.AppendText($"{textBox1.Text}\r\n");
            richTextBox1.AppendText($"{textBox2.Text}\r\n");
            richTextBox1.AppendText($"{textBox3.Text}\r\n");
            richTextBox1.AppendText($"{textBox4.Text}\r\n");
            richTextBox1.AppendText($"{textBox5.Text}\r\n");
            richTextBox1.AppendText($"{textBox6.Text}\r\n");
            richTextBox1.AppendText("\r\n");
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();

        }
    }
}
