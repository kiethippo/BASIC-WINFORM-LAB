﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LAB2
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            

            ofd.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            ofd.FilterIndex = 1;
            ofd.RestoreDirectory = true;
            ofd.ShowDialog();
            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);

          
                try
                {
                    richTextBox1.Clear();

                    using (StreamReader sr = new StreamReader(fs))
                    {
                        richTextBox1.Text = sr.ReadToEnd();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi khi đọc '{fs}'", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Textfile |*.txt";
            sfd.ShowDialog();
            FileStream fs = new FileStream(sfd.FileName, FileMode.CreateNew);
            try
            {
                if (string.IsNullOrWhiteSpace(richTextBox1.Text))
                {
                    MessageBox.Show("Không có nội dung để hiển thị");
                    return;

                }
                string[] lines = richTextBox1.Lines;
                string[] operators = { "+", "-", "*", "/" };

                string FilePath = Path.GetTempFileName();
                File.WriteAllLines(FilePath, lines);

                using (StreamWriter writer = new StreamWriter(fs))
                {
                    foreach (string line in lines)
                    {
                        //loại bỏ các ký tự không phải số
                        string ex = Regex.Replace(line, @"[^0-9+\-*/]", "");

                        //find the calculation
                        string[] calculations = ex.Split(operators, StringSplitOptions.RemoveEmptyEntries);
                        char[] ops = ex.Where(c => operators.Contains(c.ToString())).ToArray();

                        //check calculation
                        if (calculations.Length == 0 || ops.Length == 0)
                        {
                            continue;
                        }

                        double kq = double.Parse(calculations[0]);
                        for (int i = 0; i < ops.Length; i++)
                        {
                            double operand = double.Parse(calculations[i + 1]);
                            switch (ops[i])
                            {
                                case '+':
                                    kq += operand;
                                    break;
                                case '-':
                                    kq -= operand;
                                    break;
                                case '*':
                                    kq *= operand;
                                    break;
                                case '/':
                                    if (operand != 0)
                                        kq /= operand;
                                    else
                                    {
                                        writer.WriteLine($"{line} = Không thể chia cho 0");
                                        goto NextLine;
                                    }
                                    break;

                            }


                        }
                        writer.WriteLine($"{line} = {kq}");
                    NextLine:;

                    }
                }
                MessageBox.Show($"Đã tính xong và lưu kết quả vào '{fs}'");
                File.Delete(FilePath);
            }
            catch(Exception ex )
            {
                MessageBox.Show($"Lỗi: {ex.Message}");
            }
           



        }
    }
}
