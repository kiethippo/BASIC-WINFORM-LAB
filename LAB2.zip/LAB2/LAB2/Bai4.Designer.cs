﻿namespace LAB2
{
    partial class Bai4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            richTextBox1 = new RichTextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            button2 = new Button();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            button3 = new Button();
            button4 = new Button();
            label15 = new Label();
            button5 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(322, 29);
            button1.TabIndex = 0;
            button1.Text = "Write a File";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(15, 68);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(319, 27);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(15, 121);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(319, 27);
            textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(15, 176);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(319, 27);
            textBox3.TabIndex = 1;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(15, 227);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(319, 27);
            textBox4.TabIndex = 1;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(15, 277);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(319, 27);
            textBox5.TabIndex = 1;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(15, 330);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(319, 27);
            textBox6.TabIndex = 1;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(15, 385);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(319, 27);
            textBox7.TabIndex = 1;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(528, 11);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(394, 441);
            richTextBox1.TabIndex = 2;
            richTextBox1.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(374, 70);
            label1.Name = "label1";
            label1.Size = new Size(62, 25);
            label1.TabIndex = 3;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(374, 123);
            label2.Name = "label2";
            label2.Size = new Size(31, 25);
            label2.TabIndex = 3;
            label2.Text = "ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(374, 178);
            label3.Name = "label3";
            label3.Size = new Size(66, 25);
            label3.TabIndex = 3;
            label3.Text = "Phone";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(374, 229);
            label4.Name = "label4";
            label4.Size = new Size(85, 25);
            label4.TabIndex = 3;
            label4.Text = "Course 1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(374, 279);
            label5.Name = "label5";
            label5.Size = new Size(85, 25);
            label5.TabIndex = 3;
            label5.Text = "Course 2";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(374, 332);
            label6.Name = "label6";
            label6.Size = new Size(85, 25);
            label6.TabIndex = 3;
            label6.Text = "Course 3";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(374, 385);
            label7.Name = "label7";
            label7.Size = new Size(83, 25);
            label7.TabIndex = 3;
            label7.Text = "Average";
            // 
            // button2
            // 
            button2.Location = new Point(1070, 11);
            button2.Name = "button2";
            button2.Size = new Size(322, 29);
            button2.TabIndex = 0;
            button2.Text = "Button to read the file";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(944, 71);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(319, 27);
            textBox8.TabIndex = 1;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(944, 280);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(319, 27);
            textBox9.TabIndex = 1;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(944, 124);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(319, 27);
            textBox10.TabIndex = 1;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(944, 333);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(319, 27);
            textBox11.TabIndex = 1;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(944, 179);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(319, 27);
            textBox12.TabIndex = 1;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(944, 388);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(319, 27);
            textBox13.TabIndex = 1;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(944, 230);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(319, 27);
            textBox14.TabIndex = 1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(1303, 73);
            label8.Name = "label8";
            label8.Size = new Size(62, 25);
            label8.TabIndex = 3;
            label8.Text = "Name";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(1303, 126);
            label9.Name = "label9";
            label9.Size = new Size(31, 25);
            label9.TabIndex = 3;
            label9.Text = "ID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(1303, 181);
            label10.Name = "label10";
            label10.Size = new Size(66, 25);
            label10.TabIndex = 3;
            label10.Text = "Phone";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(1303, 232);
            label11.Name = "label11";
            label11.Size = new Size(85, 25);
            label11.TabIndex = 3;
            label11.Text = "Course 1";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(1303, 282);
            label12.Name = "label12";
            label12.Size = new Size(85, 25);
            label12.TabIndex = 3;
            label12.Text = "Course 2";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(1303, 335);
            label13.Name = "label13";
            label13.Size = new Size(85, 25);
            label13.TabIndex = 3;
            label13.Text = "Course 3";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(1303, 388);
            label14.Name = "label14";
            label14.Size = new Size(83, 25);
            label14.TabIndex = 3;
            label14.Text = "Average";
            // 
            // button3
            // 
            button3.Location = new Point(944, 443);
            button3.Name = "button3";
            button3.Size = new Size(122, 29);
            button3.TabIndex = 0;
            button3.Text = "Back";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(1270, 443);
            button4.Name = "button4";
            button4.Size = new Size(122, 29);
            button4.TabIndex = 0;
            button4.Text = "Next";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(1132, 447);
            label15.Name = "label15";
            label15.Size = new Size(17, 20);
            label15.TabIndex = 4;
            label15.Text = "1";
            // 
            // button5
            // 
            button5.Location = new Point(363, 457);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 5;
            button5.Text = "Add";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Bai4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1404, 517);
            Controls.Add(button5);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label7);
            Controls.Add(label13);
            Controls.Add(label6);
            Controls.Add(label12);
            Controls.Add(label5);
            Controls.Add(label11);
            Controls.Add(label4);
            Controls.Add(label10);
            Controls.Add(label3);
            Controls.Add(label9);
            Controls.Add(label2);
            Controls.Add(label8);
            Controls.Add(label1);
            Controls.Add(richTextBox1);
            Controls.Add(textBox14);
            Controls.Add(textBox4);
            Controls.Add(textBox13);
            Controls.Add(textBox7);
            Controls.Add(textBox12);
            Controls.Add(textBox3);
            Controls.Add(textBox11);
            Controls.Add(textBox6);
            Controls.Add(textBox10);
            Controls.Add(textBox2);
            Controls.Add(textBox9);
            Controls.Add(textBox5);
            Controls.Add(textBox8);
            Controls.Add(textBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Bai4";
            Text = "Bai4";
            Load += Bai4_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private RichTextBox richTextBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button button2;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Button button3;
        private Button button4;
        private Label label15;
        private Button button5;
    }
}