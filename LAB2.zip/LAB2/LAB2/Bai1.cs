﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace LAB2
{
    public partial class Bai1 : Form
    {
        public Bai1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // nút đọc file
        {
            //string inputFileName = "i1.txt";
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);


            try
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    string noidung = sr.ReadToEnd();
                    richTextBox1.Text = noidung;
                    MessageBox.Show($"Đã đọc nội dung từ file '{fs}'.");
                }

            }
            catch (FileNotFoundException)
            {
                MessageBox.Show($"File '{fs}' không tồn tại.");
            }
            catch (IOException ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi đọc '{fs}'", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e) //nút ghi file
        {
            //string outputFileName = "o1.txt";
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Textfile |*.txt"; 
            sfd.ShowDialog();
            FileStream fs = new FileStream(sfd.FileName, FileMode.CreateNew);
            try
            {
                using (StreamWriter writer = new StreamWriter(fs)) //Đọc dữ liệu của file cần out
                {
                    writer.Write(richTextBox1.Text.ToUpper());
                }
                MessageBox.Show($"nội dung của'{fs}' đã được ghi.");
            }
            catch (IOException ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi khi ghi vào file '{fs}'", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
