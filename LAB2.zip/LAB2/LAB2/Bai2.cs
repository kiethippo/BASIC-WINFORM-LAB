﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LAB2
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //richTextBox1.ScrollBars = ScrollBars.Vertical;
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "Text Files (*.txt)|*.txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string FN = ofd.SafeFileName; //Tên file 
                string FP = ofd.FileName; // URL
                textBox1.Text = FN;
                textBox3.Text = FP;
                try
                {
                    richTextBox1.Clear();
                    using (StreamReader sr = new StreamReader(FP))
                    {
                        string filecontent = sr.ReadToEnd();
                        richTextBox1.Text = filecontent;

                        //file's size
                        FileInfo fileInfo = new FileInfo(FP);
                        long fileSize = fileInfo.Length;
                        textBox2.Text = fileSize.ToString() + " bytes";

                        //Line Counter
                        int linecount = 0;
                        using (StreamReader lineReader = new StreamReader(FP))
                        {
                            while (lineReader.ReadLine() != null)
                            {
                                linecount++;
                            }
                        }
                        textBox4.Text = linecount.ToString();

                        //Text and character counter
                        int Wcount = 0; // biến đếm chữ
                        int Charcount = 0; // biến đếm kí tự
                        using (StreamReader wordReader = new StreamReader(FP))
                        {
                            string line;
                            while ((line = wordReader.ReadLine()) != null)
                            {
                                Charcount += line.Length;
                                string[] words = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                                Wcount += words.Length;
                            }
                            textBox5.Text = Wcount.ToString();
                            textBox6.Text = Charcount.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi khi đọc '{FN}'", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
    }
}
